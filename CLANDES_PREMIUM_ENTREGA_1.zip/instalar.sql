-- CLANDES PREMIUM: ampliación no destructiva.
-- Ejecutar en SQL Editor de Supabase. Requiere tablas existentes tiendas/productos.
alter table public.tiendas add column if not exists plantilla text default 'neon-tech';
alter table public.tiendas add column if not exists video_fondo_url text;
alter table public.tiendas add column if not exists portada_url text;
alter table public.tiendas add column if not exists color_primario text default '#a76cff';
alter table public.tiendas add column if not exists color_secundario text default '#53e5ff';
alter table public.tiendas add column if not exists whatsapp text;
alter table public.tiendas add column if not exists pago_instrucciones text;
alter table public.tiendas add column if not exists pago_banco text;
alter table public.tiendas add column if not exists pago_titular text;
alter table public.tiendas add column if not exists pago_clabe text;
alter table public.productos add column if not exists imagen_url text;
alter table public.productos add column if not exists video_url text;
alter table public.productos add column if not exists tipo_media text default 'imagen';

create table if not exists public.clandes_clientes (
 id uuid primary key default gen_random_uuid(), tienda_id uuid not null references public.tiendas(id) on delete cascade,
 usuario_id uuid not null references auth.users(id) on delete cascade,
 nombre text not null default '', telefono text default '', creado timestamptz not null default now(),
 unique(tienda_id,usuario_id)
);
create table if not exists public.clandes_reportes (
 id uuid primary key default gen_random_uuid(), tienda_id uuid not null references public.tiendas(id) on delete cascade,
 cliente_id uuid not null references auth.users(id), producto text not null, referencia text default '',
 fecha_compra date, fecha_falla date, problema text not null,
 respuesta text default '', estado text not null default 'pendiente' check(estado in ('pendiente','en proceso','solucionado')),
 creado timestamptz not null default now(), actualizado timestamptz not null default now()
);
create table if not exists public.clandes_mensajes (
 id uuid primary key default gen_random_uuid(), tienda_id uuid not null references public.tiendas(id) on delete cascade,
 cliente_id uuid not null references auth.users(id), autor_id uuid not null references auth.users(id),
 mensaje text not null check(char_length(mensaje) between 1 and 2000), creado timestamptz not null default now()
);
create table if not exists public.clandes_saldos (
 tienda_id uuid not null references public.tiendas(id) on delete cascade,
 cliente_id uuid not null references auth.users(id), centavos bigint not null default 0 check(centavos>=0),
 primary key(tienda_id,cliente_id)
);
create table if not exists public.clandes_movimientos (
 id uuid primary key default gen_random_uuid(), tienda_id uuid not null references public.tiendas(id) on delete cascade,
 cliente_id uuid not null references auth.users(id), centavos bigint not null,
 motivo text not null, actor_id uuid not null references auth.users(id), creado timestamptz not null default now()
);

create or replace function public.clandes_es_dueno(t uuid) returns boolean
language sql stable security definer set search_path = '' as $$
 select exists(select 1 from public.tiendas where id=t and propietario_id=(select auth.uid()) and estado='activa')
$$;
revoke all on function public.clandes_es_dueno(uuid) from public;
grant execute on function public.clandes_es_dueno(uuid) to authenticated;

alter table public.clandes_clientes enable row level security;
alter table public.clandes_reportes enable row level security;
alter table public.clandes_mensajes enable row level security;
alter table public.clandes_saldos enable row level security;
alter table public.clandes_movimientos enable row level security;

create policy "clandes_clientes_lectura" on public.clandes_clientes for select to authenticated using(usuario_id=(select auth.uid()) or public.clandes_es_dueno(tienda_id));
create policy "clandes_clientes_alta" on public.clandes_clientes for insert to authenticated with check(usuario_id=(select auth.uid()) and exists(select 1 from public.tiendas t where t.id=tienda_id and t.estado='activa'));
create policy "clandes_reportes_lectura" on public.clandes_reportes for select to authenticated using(cliente_id=(select auth.uid()) or public.clandes_es_dueno(tienda_id));
create policy "clandes_reportes_alta" on public.clandes_reportes for insert to authenticated with check(cliente_id=(select auth.uid()) and exists(select 1 from public.clandes_clientes c where c.tienda_id=clandes_reportes.tienda_id and c.usuario_id=(select auth.uid())));
create policy "clandes_reportes_dueno_actualiza" on public.clandes_reportes for update to authenticated using(public.clandes_es_dueno(tienda_id)) with check(public.clandes_es_dueno(tienda_id));
create policy "clandes_mensajes_lectura" on public.clandes_mensajes for select to authenticated using(cliente_id=(select auth.uid()) or public.clandes_es_dueno(tienda_id));
create policy "clandes_mensajes_alta" on public.clandes_mensajes for insert to authenticated with check(autor_id=(select auth.uid()) and (cliente_id=(select auth.uid()) or public.clandes_es_dueno(tienda_id)) and exists(select 1 from public.clandes_clientes c where c.tienda_id=clandes_mensajes.tienda_id and c.usuario_id=clandes_mensajes.cliente_id));
create policy "clandes_saldos_lectura" on public.clandes_saldos for select to authenticated using(cliente_id=(select auth.uid()) or public.clandes_es_dueno(tienda_id));
create policy "clandes_movimientos_lectura" on public.clandes_movimientos for select to authenticated using(cliente_id=(select auth.uid()) or public.clandes_es_dueno(tienda_id));

-- Ajuste de saldo transaccional: solo propietario, con historial inmutable.
create or replace function public.clandes_ajustar_saldo(p_tienda uuid,p_cliente uuid,p_centavos bigint,p_motivo text)
returns bigint language plpgsql security definer set search_path='' as $$
declare nuevo bigint;
begin
 if not public.clandes_es_dueno(p_tienda) then raise exception 'No autorizado'; end if;
 if p_centavos=0 or abs(p_centavos)>100000000 then raise exception 'Monto inválido'; end if;
 if char_length(trim(coalesce(p_motivo,'')))<3 then raise exception 'Escribe un motivo'; end if;
 if not exists(select 1 from public.clandes_clientes where tienda_id=p_tienda and usuario_id=p_cliente) then raise exception 'Cliente no registrado en esta tienda'; end if;
 insert into public.clandes_saldos(tienda_id,cliente_id,centavos) values(p_tienda,p_cliente,0) on conflict do nothing;
 update public.clandes_saldos set centavos=centavos+p_centavos where tienda_id=p_tienda and cliente_id=p_cliente and centavos+p_centavos>=0 returning centavos into nuevo;
 if nuevo is null then raise exception 'Saldo insuficiente'; end if;
 insert into public.clandes_movimientos(tienda_id,cliente_id,centavos,motivo,actor_id) values(p_tienda,p_cliente,p_centavos,p_motivo,(select auth.uid()));
 return nuevo;
end $$;
revoke all on function public.clandes_ajustar_saldo(uuid,uuid,bigint,text) from public;
grant execute on function public.clandes_ajustar_saldo(uuid,uuid,bigint,text) to authenticated;

-- Actualización limitada de configuración de tienda para su propietario.
-- La política existente de tiendas debe permitir UPDATE del propietario.
-- NO se conceden permisos generales de UPDATE sobre saldos ni movimientos.

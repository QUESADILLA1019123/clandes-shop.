-- Ejecuta en Supabase SQL Editor para revisar políticas actuales.
-- NO modifica ni borra información.
select schemaname,tablename,policyname,cmd,roles,qual,with_check
from pg_policies where schemaname='public' and tablename in
('tiendas','productos','inventario_digital','clientes_tienda','pedidos','clandes_clientes','clandes_reportes','clandes_mensajes','clandes_saldos','clandes_movimientos')
order by tablename,policyname;
select tablename,rowsecurity from pg_tables where schemaname='public' and tablename in
('tiendas','productos','inventario_digital','clientes_tienda','pedidos','clandes_clientes','clandes_reportes','clandes_mensajes','clandes_saldos','clandes_movimientos') order by tablename;
